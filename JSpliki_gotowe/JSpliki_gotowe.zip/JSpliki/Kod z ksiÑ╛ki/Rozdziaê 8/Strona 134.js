var podwajaj = function (liczba) {
  return liczba * 2;
};

podwajaj(3);
// 6

podwajaj(5) + podwajaj(6);
// 22

podwajaj(podwajaj(3));
// 12
