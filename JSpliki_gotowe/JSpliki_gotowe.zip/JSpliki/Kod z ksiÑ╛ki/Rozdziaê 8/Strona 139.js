var pi�taLitera = function (imi�) {
  if (imi�.length < 5) {
    return;
  }

  return "Pi�ta litera Twojego imienia to " + imi�[4] + ".";
};

pi�taLitera("Tadeusz");
// "Pi�ta litera Twojego imienia to u."

pi�taLitera("Maja");
// undefined
