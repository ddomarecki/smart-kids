var naszaPierwszaFunkcja = function () {
  console.log("Hello world!");
};

naszaPierwszaFunkcja();
// Hello world!
