var rysujKoty = function (ileRazy) {
  for (var i = 0; i < ileRazy; i++) {
    console.log(i + " =^.^=");
  }
};

rysujKoty(5);
// 0 =^.^=
// 1 =^.^=
// 2 =^.^=
// 3 =^.^=
// 4 =^.^=
