var rysujWieleRazy = function (ileRazy, coRysowa�) {
  for (var i = 0; i < ileRazy; i++) {
    console.log(i + " " + coRysowa�);
  }
};

rysujWieleRazy(5, "=^.^=");
// 0 =^.^=
// 1 =^.^=
// 2 =^.^=
// 3 =^.^=
// 4 =^.^=

rysujWieleRazy(4, "^_^");
// 0 ^_^
// 1 ^_^
// 2 ^_^
// 3 ^_^

rysujWieleRazy(2, "(>_<)");
// 0 (>_<)
// 1 (>_<)
