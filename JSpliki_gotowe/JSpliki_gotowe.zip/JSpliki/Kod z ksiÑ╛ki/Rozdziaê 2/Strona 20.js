var sekundyWMinucie = 60;
var minutyWGodzinie = 60;
var sekundyWGodzinie = sekundyWMinucie * minutyWGodzinie;
sekundyWGodzinie;
// 3600

var godzinyWDobie = 24;
var sekundyWDobie = sekundyWGodzinie * godzinyWDobie;
sekundyWDobie;
// 86400

var dniWRoku = 365;
var sekundyWRoku = sekundyWDobie * dniWRoku;
sekundyWRoku;
// 31536000

var wiek = 29;
wiek * sekundyWRoku;
// 914544000
