var mojaTajnaLiczba = 5;
var strza�Bolka = 3;
mojaTajnaLiczba === strza�Bolka;
// false

var strza�Lolka = 7;
mojaTajnaLiczba === strza�Lolka;
// false

var strza�Toli = 5;
mojaTajnaLiczba === strza�Toli;
// true
