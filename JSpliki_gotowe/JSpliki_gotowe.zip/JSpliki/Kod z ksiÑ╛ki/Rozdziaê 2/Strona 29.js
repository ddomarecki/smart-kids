var g�upiTekst = "hEj TAM, cO Ty WYprAwiASZ?";
var tekstMa�eLitery = g�upiTekst.toLowerCase();
var pierwszyZnak = tekstMa�eLitery[0];
var pierwszyZnakWielkaLitera = pierwszyZnak.toUpperCase();
var resztaTekstu = tekstMa�eLitery.slice(1);
pierwszyZnakWielkaLitera + resztaTekstu;
// "Hej tam, co ty wyprawiasz?"
