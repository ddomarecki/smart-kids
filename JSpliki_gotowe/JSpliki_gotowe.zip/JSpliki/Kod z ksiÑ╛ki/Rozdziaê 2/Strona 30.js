var g�upiTekst = "hEj TAM, cO Ty WYprAwiASZ?";
g�upiTekst[0].toUpperCase() + g�upiTekst.slice(1).toLowerCase();
// "Hej tam, co ty wyprawiasz?"
