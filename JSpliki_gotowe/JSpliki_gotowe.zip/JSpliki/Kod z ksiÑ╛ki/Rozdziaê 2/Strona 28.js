"Hej tam, co ty wyprawiasz?".toUpperCase();
// "HEJ TAM, CO TY WYPRAWIASZ?"

"hEj TAM, cO Ty WYprAwiASZ?".toLowerCase();
// "hej tam, co ty wyprawiasz?"
