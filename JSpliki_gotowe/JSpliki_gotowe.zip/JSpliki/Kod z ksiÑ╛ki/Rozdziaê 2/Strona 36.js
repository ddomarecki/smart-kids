var liczbaJakoTekst = "5";
var prawdziwaLiczba = 5;
liczbaJakoTekst === prawdziwaLiczba;
// false

liczbaJakoTekst == prawdziwaLiczba;
// true

0 == false;
// true

"false" == false;
// false
