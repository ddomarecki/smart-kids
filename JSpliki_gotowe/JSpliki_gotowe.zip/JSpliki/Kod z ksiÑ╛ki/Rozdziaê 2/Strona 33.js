var wzrost = 165;
var limitWzrostu = 150;
wzrost > limitWzrostu;
// true

var wzrost = 150;
var limitWzrostu = 150;
wzrost > limitWzrostu;
// false

var wzrost = 150;
var limitWzrostu = 150;
wzrost >= limitWzrostu;
// true

var wzrost = 150;
var limitWzrostu = 120;
wzrost < limitWzrostu;
// false

var wzrost = 120;
var limitWzrostu = 120;
wzrost <= limitWzrostu;
// true
