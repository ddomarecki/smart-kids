var s�owoKodu1 = "are";
var s�owoKodu2 = "tubas";
var s�owoKodu3 = "unsafe";
var s�owoKodu4 = "?!";
s�owoKodu1[1] + s�owoKodu2[1] + s�owoKodu3[1] + s�owoKodu4[1];
// "run!"
