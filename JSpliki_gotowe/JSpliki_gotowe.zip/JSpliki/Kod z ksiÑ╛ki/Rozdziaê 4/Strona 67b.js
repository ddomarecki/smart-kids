var kot = {};
kot["�apy"] = 4;
kot["imi�"] = "Rademenes";
kot["kolor"] = "kruczoczarny";
kot;
// { kolor: "kruczoczarny", �apy: 3, imi�: "Rademenes" }
