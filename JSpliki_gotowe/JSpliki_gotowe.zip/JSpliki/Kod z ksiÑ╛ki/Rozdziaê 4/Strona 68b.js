var pies = {
  imi�: "Chojrak",
  �apy: 4,
  jestKochany: true
};
pies.maPch�y;