var pies = { imi�: "Chojrak", wiek: 6, kolor: "rudobrunatny", odg�os: "Hau hau!" };
var kot = { imi�: "Rademenes", wiek: 8, kolor: "kruczoczarny" };
Object.keys(pies);
// ["imi�", "wiek", "kolor", "odg�os"]
Object.keys(kot);
// ["imi�", "wiek", "kolor"]
