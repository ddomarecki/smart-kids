var kot = {};
kot.�apy = 4;
kot.imi� = "Rademenes";
kot.kolor = "kruczoczarny";