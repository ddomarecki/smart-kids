var kot = {
  �apy: 4,
  imi�: "Rademenes",
  color: "kruczoczarny"
};

kot["imi�"];
// "Rademenes"

kot.imi�;
// "Rademenes"
