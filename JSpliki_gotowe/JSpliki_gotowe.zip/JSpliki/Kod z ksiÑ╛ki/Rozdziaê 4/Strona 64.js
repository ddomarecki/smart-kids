var kot = {
  "�apy": 4,
  "imi�": "Rademenes",
  "kolor": "kruczoczarny"
};
