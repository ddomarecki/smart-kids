var kot = {
  �apy: 4,
  imi�: "Rademenes",
  kolor: "kruczoczarny"
};

var kot = {
  �apy: 4,
  "imi� i nazwisko": "Rademenes Faraon Hathor",
  kolor: "kruczoczarny"
};