// Narysuj tyle kot�w ile zechcesz!
var rysujKoty = function (ileRazy) {
  for (var i = 0; i < ileRazy; i++) {
    console.log(i + " =^.^=");
  }
};

rysujKoty(10); // Zamiast 10 mo�na wstawi� dowoln� liczb�.

// 0 =^.^=
// 1 =^.^=
// 2 =^.^=
// 3 =^.^=
// 4 =^.^=
// 5 =^.^=
// 6 =^.^=
// 7 =^.^=
// 8 =^.^=
// 9 =^.^=
