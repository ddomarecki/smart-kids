var pies = {
  imi�: "Chojrak",
  �apy: 4,
  jestKochany: true
};

pies.szczekni�cie = function () {
  console.log("Hau hau! Nazywam si� " + this.imi� + "!");
};

pies.szczekni�cie();
// Hau hau! Nazywam si� Chojrak!
