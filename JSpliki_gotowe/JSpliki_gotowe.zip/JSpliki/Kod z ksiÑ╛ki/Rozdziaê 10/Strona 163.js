var odr�bZadanieDomowe = function () {
  alert("Hej! Musisz odrobi� zadanie!");
};

var idCzasuZw�oki = setTimeout(odr�bZadanieDomowe, 60000);

clearTimeout(idCzasuZw�oki);