var ju�Czas = function () {
  alert("Ju� czas!");
};

setTimeout(ju�Czas, 3000);
// 1

setTimeout(ju�Czas, 5000);
// 2
