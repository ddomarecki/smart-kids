var zwierz�taFutrzaste = ["Alpaka", "Lemur Katta", "Yeti"];
var zwierz�ta�uszczaste = ["Boa Dusiciel", "Godzilla"];
var zwierz�taFutrzasteI�uszczaste = zwierz�taFutrzaste.concat(zwierz�ta�uszczaste);
zwierz�taFutrzasteI�uszczaste;
// ["Alpaka", "Lemur Katta", "Yeti", "Boa Dusiciel", "Godzilla"]
zwierz�taFutrzaste;
// ["Alpaka", "Lemur Katta", "Yeti"]
zwierz�ta�uszczaste;
// ["Boa Dusiciel", "Godzilla"]

var zwierz�taFutrzaste = ["Alpaka", "Lemur Katta", "Yeti"];
var zwierz�ta�uszczaste = ["Boa Dusiciel", "Godzilla"];
var zwierz�taPierzaste = ["Ara", "Dodo"];
var wszystkieZwierz�ta = zwierz�taFutrzaste.concat(zwierz�ta�uszczaste, zwierz�taPierzaste);
wszystkieZwierz�ta;
// ["Alpaka", "Lemur Katta", "Yeti", "Boa Dusiciel", "Godzilla", "Ara", "Dodo"]