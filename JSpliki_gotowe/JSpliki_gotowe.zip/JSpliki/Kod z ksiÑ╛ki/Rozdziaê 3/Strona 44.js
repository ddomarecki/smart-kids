var dinozaury = [];
dinozaury[0] = "Tyranozaur";
dinozaury[1] = "Welociraptor";
dinozaury[2] = "Stegozaur";
dinozaury[3] = "Triceratops";
dinozaury[4] = "Brachiozaur";
dinozaury[5] = "Pteranodon";
dinozaury[6] = "Apatozaur";
dinozaury[7] = "Diplodok";
dinozaury[8] = "Kompsognat";
dinozaury;
// ["Tyranozaur", "Welociraptor", "Stegozaur", "Triceratops", "Brachiozaur", "Pteranodon", "Apatozaur", "Diplodok", "Kompsognat"]
