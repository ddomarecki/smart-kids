var dinozaury = [
  "Tyranozaur",
  "Welociraptor",
  "Stegozaur",
  "Triceratops",
  "Brachiozaur",
  "Pteranodon",
  "Apatozaur",
  "Diplodok",
  "Kompsognat"
];