var dinozauryOrazLiczby = [3, "dinozaury", ["triceratops", "stegozaur", 3627.5], 10];

dinozauryOrazLiczby[2];
// ["triceratops", "stegozaur", 3627.5]

dinozauryOrazLiczby[2][0];
// "triceratops"
