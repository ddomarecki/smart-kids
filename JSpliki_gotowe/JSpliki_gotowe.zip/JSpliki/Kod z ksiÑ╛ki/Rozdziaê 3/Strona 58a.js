var losoweS�owa = ["Wybuch", "Jaskinia", "Ksi�niczka", "Pi�ro"];
var losowyIndeks = Math.floor(Math.random() * 4);
losoweS�owa[losowyIndeks];
// "Jaskinia"

losoweS�owa[Math.floor(Math.random() * 4)];
// "Ksi�niczka"
