var zdania = [
"Brzmi dobrze",
"Tak, zdecydowanie powiniene� to zrobi�",
"Nie jestem w pe�ni przekonany do tego pomys�u",
"Mo�e nie dzisiaj?",
"Komputer m�wi nie"
];

// Powinienem zrobi� sobie kolejny koktail?
zdania[Math.floor(Math.random() * 5)];
// "Nie jestem w pe�ni przekonany do tego pomys�u"

// Powinienem odrobi� zadanie domowe?
zdania[Math.floor(Math.random() * 5)];
// "Mo�e nie dzisiaj?"
