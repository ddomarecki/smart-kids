var punktyOrientacyjne = [];
punktyOrientacyjne.push("M�j dom");
punktyOrientacyjne.push("�cie�ka przed domem");
punktyOrientacyjne.push("Migaj�ca latarnia");
punktyOrientacyjne.push("Ciekn�cy hydrant");
punktyOrientacyjne.push("Stra� po�arna");
punktyOrientacyjne.push("Schronisko dla kot�w");
punktyOrientacyjne.push("Moja stara szko�a");
punktyOrientacyjne.push("Dom mojej przyjaci�ki");

punktyOrientacyjne.pop();
// "Dom mojej przyjaci�ki"
punktyOrientacyjne.pop();
// "Moja stara szko�a"
punktyOrientacyjne.pop();
// "Schronisko dla kot�w"
punktyOrientacyjne.pop();
// "Stra� po�arna"
punktyOrientacyjne.pop();
// "Ciekn�cy hydrant"
punktyOrientacyjne.pop();
// "Migaj�ca latarnia"
punktyOrientacyjne.pop();
// "�cie�ka przed domem"
punktyOrientacyjne.pop();
// "M�j dom"
