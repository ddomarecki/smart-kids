var kolory = ["czerwony", "zielony", "niebieski"];
kolory.indexOf("niebieski");
// 2
kolory.indexOf("zielony");
// 1

kolory[2];
// "niebieski"
kolory.indexOf("niebieski");
2

kolory.indexOf("purpurowy");
// -1

var insekty = ["Pszczo�a", "Mr�wka", "Pszczo�a", "Pszczo�a", "Mr�wka"];
insekty.indexOf("Pszczo�a");
// 0
