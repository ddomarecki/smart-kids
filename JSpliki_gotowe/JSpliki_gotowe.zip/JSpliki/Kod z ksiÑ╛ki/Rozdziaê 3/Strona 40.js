var mojeTrzyUlubioneDinozaury = ["Tyranozaur", "Welociraptor", "Stegozaur"];

var dinozaur1 = "Tyranozaur";
var dinozaur2 = "Welociraptor";
var dinozaur3 = "Stegozaur";
var dinozaur4 = "Triceratops";
var dinozaur5 = "Brachiozaur";
var dinozaur6 = "Pteranodon";
var dinozaur7 = "Apatozaur";
var dinozaur8 = "Diplodok";
var dinozaur9 = "Kompsognat";