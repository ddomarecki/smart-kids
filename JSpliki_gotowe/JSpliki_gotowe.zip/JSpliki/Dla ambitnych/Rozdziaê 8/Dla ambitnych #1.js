var dodawaj = function (a, b) {
  return a + b;
};

var mn� = function (a, b) {
  return a * b;
};

dodawaj(mn�(36325, 9824), 777);
// 356857577
