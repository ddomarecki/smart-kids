var m�jSzalonyObiekt = {
  "nazwa": "Niedorzeczny obiekt",
  "jaka� tablica": [7, 9, { cel: "zamieszanie", liczba: 123 }, 3.3], "losowe zwierz�": "rekin banano�erny"
};

m�jSzalonyObiekt["jaka� tablica"][2].liczba;
// 123
