var wyniki = {
  patrycja: 0,
  filip: 0
};

// Zwi�ksz wynik Filipa o 100
wyniki.filip += 100;

// Zwi�ksz wynik Patrycji o 90
wyniki.patrycja += 90;

// Wy�wietl wyniki
wyniki;
// { patrycja: 90, filip: 100 }
